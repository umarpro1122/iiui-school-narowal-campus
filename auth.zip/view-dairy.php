<!DOCTYPE html>
<html>
<head>
  <title>Daily Diary - Chaman/Chandowal Campus</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background-color: #f0f8ff;
    }
    h2 {
      color: #333;
    }
    pre {
      background-color: #fff;
      padding: 20px;
      border: 1px solid #ccc;
      white-space: pre-wrap;
      word-wrap: break-word;
    }
  </style>
</head>
<body>
  <h2>📝 Daily Diary</h2>
  <pre>
<?php
  if (file_exists("diary.txt")) {
      echo htmlspecialchars(file_get_contents("diary.txt"));
  } else {
      echo "No diary entries yet.";
  }
?>
  </pre>
</body>
</html>
