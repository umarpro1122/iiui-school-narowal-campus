<?php
require_once 'vendor/autoload.php'; // Path to Twilio SDK

use Twilio\Rest\Client;

// Twilio credentials
$sid = 'YOUR_ACCOUNT_SID';
$token = 'YOUR_AUTH_TOKEN';
$client = new Client($sid, $token);

// Collect data from form
$student_name = $_POST['student_name'];
$father_name = $_POST['father_name'];
$contact = $_POST['contact'];

$messageBody = "New Admission Request:\nStudent: $student_name\nFather: $father_name\nContact: $contact";

// Send SMS to your number
$client->messages->create(
    '+92XXXXXXXXXX', // Your mobile number in international format
    [
        'from' => 'YOUR_TWILIO_NUMBER',
        'body' => $messageBody
    ]
);

echo "SMS sent successfully!";
?>
